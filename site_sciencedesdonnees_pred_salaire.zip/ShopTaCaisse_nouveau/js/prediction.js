document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('prediction-form');
    const resultat = document.getElementById('resultat');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const formData = new FormData(form);

        fetch('predict_salary.php', {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                resultat.classList.remove('resultat-cache');
                resultat.innerHTML = `
                    <h2>Résultat</h2>
                    <p>Le salaire estimé est de <strong>${data.salary}</strong>.</p>
                    <p class="petit">Estimation réalisée à partir des informations saisies dans le formulaire.</p>
                `;
            } else {
                resultat.classList.remove('resultat-cache');
                resultat.innerHTML = `<p>${data.message}</p>`;
            }
        })
        .catch(() => {
            resultat.classList.remove('resultat-cache');
            resultat.innerHTML = '<p>Une erreur est survenue pendant le calcul.</p>';
        });
    });
});
