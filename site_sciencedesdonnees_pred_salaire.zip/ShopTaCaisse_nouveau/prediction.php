<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ShopTaCaisse - Prédiction</title>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body class="inscription">
    <main class="conteneur-page">
        <h1>Estimation d'un salaire</h1>
        <p><a href="index.php" class="accueil">Retour à l'accueil</a></p>

        <form id="prediction-form" class="form">
            <p>
                <label for="year">Année :</label><br>
                <input type="number" id="year" name="year" min="2010" max="2025" value="2025" required>
            </p>

            <p>
                <label for="region">Région :</label><br>
                <select id="region" name="region" required>
                    <option value="North America">North America</option>
                    <option value="Europe">Europe</option>
                    <option value="East Asia">East Asia</option>
                    <option value="South Asia">South Asia</option>
                    <option value="Middle East">Middle East</option>
                    <option value="South America">South America</option>
                    <option value="Africa">Africa</option>
                    <option value="Oceania">Oceania</option>
                </select>
            </p>

            <p>
                <label for="industry">Secteur :</label><br>
                <select id="industry" name="industry" required>
                    <option value="Tech">Tech</option>
                    <option value="Finance">Finance</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Education">Education</option>
                    <option value="Government">Government</option>
                    <option value="Retail">Retail</option>
                    <option value="Energy">Energy</option>
                    <option value="Manufacturing">Manufacturing</option>
                    <option value="Agriculture">Agriculture</option>
                </select>
            </p>

            <p>
                <label for="company_size">Taille de l'entreprise :</label><br>
                <select id="company_size" name="company_size" required>
                    <option value="Startup">Startup</option>
                    <option value="Small">Small</option>
                    <option value="Medium">Medium</option>
                    <option value="Large">Large</option>
                </select>
            </p>

            <p>
                <label for="seniority_level">Niveau d'expérience :</label><br>
                <select id="seniority_level" name="seniority_level" required>
                    <option value="Intern">Intern</option>
                    <option value="Junior">Junior</option>
                    <option value="Mid">Mid</option>
                    <option value="Senior">Senior</option>
                    <option value="Lead">Lead</option>
                    <option value="Executive">Executive</option>
                </select>
            </p>

            <p>
                <label for="job_title">Métier :</label><br>
                <select id="job_title" name="job_title" required>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="ML Engineer">ML Engineer</option>
                    <option value="AI Researcher">AI Researcher</option>
                    <option value="Software Engineer">Software Engineer</option>
                    <option value="Research Scientist">Research Scientist</option>
                    <option value="Business Analyst">Business Analyst</option>
                    <option value="Systems Engineer">Systems Engineer</option>
                    <option value="Product Manager">Product Manager</option>
                    <option value="Operations Manager">Operations Manager</option>
                    <option value="Policy Analyst">Policy Analyst</option>
                </select>
            </p>

            <p>
                <label for="automation_risk_score">Score de risque d'automatisation (0 à 1) :</label><br>
                <input type="number" id="automation_risk_score" name="automation_risk_score" min="0" max="1" step="0.01" value="0.30" required>
            </p>

            <p>
                <label for="ai_intensity_score">Score d'intensité d'usage (0 à 1) :</label><br>
                <input type="number" id="ai_intensity_score" name="ai_intensity_score" min="0" max="1" step="0.01" value="0.40" required>
            </p>

            <p><button type="submit" class="bouton">Estimer le salaire</button></p>
        </form>

        <section id="resultat" class="bloc resultat-cache"></section>
    </main>

    <script src="js/prediction.js"></script>
</body>
</html>
