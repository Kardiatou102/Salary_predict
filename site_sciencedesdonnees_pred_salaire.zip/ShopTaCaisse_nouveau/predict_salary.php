<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Requête invalide.'
    ]);
    exit;
}

$year = isset($_POST['year']) ? (int) $_POST['year'] : 2025;
$region = $_POST['region'] ?? '';
$industry = $_POST['industry'] ?? '';
$company_size = $_POST['company_size'] ?? '';
$seniority_level = $_POST['seniority_level'] ?? '';
$job_title = $_POST['job_title'] ?? '';
$automation_risk_score = isset($_POST['automation_risk_score']) ? (float) $_POST['automation_risk_score'] : 0;
$ai_intensity_score = isset($_POST['ai_intensity_score']) ? (float) $_POST['ai_intensity_score'] : 0;

if ($automation_risk_score < 0 || $automation_risk_score > 1 || $ai_intensity_score < 0 || $ai_intensity_score > 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Les scores doivent être compris entre 0 et 1.'
    ]);
    exit;
}

$region_bonus = [
    'North America' => 24000,
    'Europe' => 14000,
    'Oceania' => 13000,
    'Middle East' => 10000,
    'East Asia' => 9000,
    'South America' => 4000,
    'South Asia' => 2500,
    'Africa' => 1500
];

$industry_bonus = [
    'Tech' => 18000,
    'Finance' => 13000,
    'Healthcare' => 9000,
    'Energy' => 8500,
    'Government' => 5000,
    'Retail' => 3500,
    'Manufacturing' => 4500,
    'Education' => 3000,
    'Agriculture' => 2500
];

$company_bonus = [
    'Startup' => 1500,
    'Small' => 3000,
    'Medium' => 5000,
    'Large' => 7500
];

$seniority_bonus = [
    'Intern' => -18000,
    'Junior' => -8000,
    'Mid' => 0,
    'Senior' => 12000,
    'Lead' => 18000,
    'Executive' => 26000
];

$job_bonus = [
    'AI Researcher' => 17000,
    'ML Engineer' => 16000,
    'Data Scientist' => 14000,
    'Research Scientist' => 12000,
    'Software Engineer' => 10000,
    'Product Manager' => 9000,
    'Systems Engineer' => 7500,
    'Operations Manager' => 6500,
    'Business Analyst' => 5500,
    'Policy Analyst' => 4500
];

$salary = 28000;
$salary += ($year - 2010) * 900;
$salary += $region_bonus[$region] ?? 0;
$salary += $industry_bonus[$industry] ?? 0;
$salary += $company_bonus[$company_size] ?? 0;
$salary += $seniority_bonus[$seniority_level] ?? 0;
$salary += $job_bonus[$job_title] ?? 0;
$salary += $ai_intensity_score * 22000;
$salary -= $automation_risk_score * 10000;

$salary = max(18000, min(170000, round($salary)));
$salary_formatted = number_format($salary, 0, ',', ' ') . ' $';

echo json_encode([
    'success' => true,
    'salary' => $salary_formatted
], JSON_UNESCAPED_UNICODE);
