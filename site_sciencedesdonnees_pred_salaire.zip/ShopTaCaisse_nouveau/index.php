<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Projet salaires</title>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body class="index">
    <header>
        <h1 class="accueil">Projet science des données</h1>
        <p class="accueil"><strong>Étude de données sur les salaires selon les métiers et leur fréquence d'utilisation de l'IA</strong></p>
    </header>

    <main class="conteneur">
        <section class="bloc">
            <h2>Présentation rapide</h2>
            <p>
                Bienvenue sur notre site. Ce projet a pour but d'étudier un jeu de données portant sur les métiers,
                les salaires et plusieurs caractéristiques du poste afin de voir s'il existe un lien entre le niveau de salaire
                et la fréquence d'utilisation de l'IA dans le travail.
            </p>
            <p>
                Pour le moment, le projet contient une partie d'exploration des données, une partie de présentation,
                puis une page d'estimation de salaire à partir d'informations saisies par l'utilisateur.
            </p>
        </section>

        <section class="bloc">
            <h2>Accès aux pages</h2>
            <p><a href="donnees.html" class="accueil">Voir la page de présentation des données</a></p>
            <p><a href="prediction.php" class="accueil">Aller à la page de prédiction</a></p>
        </section>
    </main>
</body>
</html>
